export const SDK_VERSION = '6.4.1';
