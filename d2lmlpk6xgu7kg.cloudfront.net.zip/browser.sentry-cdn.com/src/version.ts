// TODO: Remove in the next major release and rely only on @sentry/core SDK_VERSION and SdkInfo metadata
export const SDK_NAME = 'sentry.javascript.browser';
